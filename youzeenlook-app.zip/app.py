import streamlit as st
from ai_model import recommend_outfits
import json

st.set_page_config(page_title="YouzeenLook - AI Fashion Recommender", layout="centered")

st.title("🧠 YouzeenLook - AI Fashion Assistant")
st.write("Find your perfect outfit based on your height, weight, and skin tone.")

height = st.number_input("Height (cm)", min_value=100, max_value=250)
weight = st.number_input("Weight (kg)", min_value=30, max_value=200)
skin_tone = st.selectbox("Skin Tone", ["Light", "Wheatish", "Tan", "Dark"])

if st.button("Recommend Outfits"):
    results = recommend_outfits(height, weight, skin_tone)
    st.success("Here are your recommended outfits:")
    for item in results:
        st.markdown(f"- 👕 {item}")

st.caption("Coming soon: Try outfits in Augmented Reality 👓")
